let count = 0;
let isPropagation = true;
let blueClicked = true;
let redClicked = false;
let yellowClicked = false;
let order = true;

document.querySelector('#propagation').onclick = () =>{
    if(isPropagation) document.querySelector('#propagation').innerHTML = "START PROPAGATION";
    else document.querySelector('#propagation').innerHTML = "STOP PROPAGATION";
    isPropagation = !isPropagation;
}

document.querySelector('#order').onclick = () =>{
    order = !order;
}

function displayLabel1(){

    document.querySelector('#text').innerHTML = "";

    if (blueClicked){
        document.querySelector('#text').innerHTML+= "nacisnąłeś niebieski o wartości 1 <br>"
        blueClicked = false;
    }
    if (redClicked){
        document.querySelector('#text').innerHTML+= "nacisnąłeś czerwony o wartości 2 <br>"
        redClicked = false;
    }   
    if (yellowClicked){
        document.querySelector('#text').innerHTML+= "nacisnąłeś żółty o wartości 5 <br>"
        yellowClicked = false
    }
}

function displayLabel2(){

    document.querySelector('#text').innerHTML = "";

    if (yellowClicked){
        document.querySelector('#text').innerHTML+= "nacisnąłeś żółty o wartości 5 <br>"
        yellowClicked = false
    }
    if (redClicked){
        document.querySelector('#text').innerHTML+= "nacisnąłeś czerwony o wartości 2 <br>"
        redClicked = false;
    }   
    if (blueClicked){
        document.querySelector('#text').innerHTML+= "nacisnąłeś niebieski o wartości 1 <br>"
        blueClicked = false;
    }
   
}

function addToCounter(points){
    count += points;
    document.querySelector('#counter').innerHTML = count;
    if(count > 30){
        document.querySelector('#container-2').style.backgroundColor = "grey"; 
        document.querySelector('#container-2').style.pointerEvents = 'none';
    }
    if(count > 50){
        document.querySelector('#container-3').style.backgroundColor = "grey";
        document.querySelector('#container-3').style.pointerEvents = 'none';
    }
}


document.querySelector('#container-1').onclick = () =>{
    addToCounter(1); 
    blueClicked = true;
    if(order) displayLabel1();
    else displayLabel2();
}

document.querySelector('#container-2').onclick = () =>{
    addToCounter(2);
    redClicked = true;
    if (!isPropagation){
        if(order) displayLabel1();
        else displayLabel2();
        event.stopPropagation();
    } 
           
}

document.querySelector('#container-3').onclick = () =>{
    addToCounter(5); 
    document.querySelector('#counter').innerHTML = count;
    yellowClicked = true;
    if (!isPropagation){
        if(order) displayLabel1();
        else displayLabel2();
        event.stopPropagation();
    }
        
}

document.querySelector('#reset').onclick = () =>{
    count = 0;
    document.querySelector('#counter').innerHTML = count;
    document.querySelector('#container-2').style.pointerEvents = 'auto'; 
    document.querySelector('#container-2').style.backgroundColor = "red"; 
    document.querySelector('#container-3').style.pointerEvents = 'auto'; 
    document.querySelector('#container-3').style.backgroundColor = "yellow";
}



